export const colors = {
  background: "#030712",
  surface: "#0B1221",
  primary: "#2BD4C5",
  secondary: "#3A7CFF",
  textPrimary: "#F5F7FF",
  textSecondary: "#94A3B8",
  border: "#172039",
  muted: "#101932",
};
