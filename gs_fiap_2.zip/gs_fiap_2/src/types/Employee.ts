export type Employee = {
  id: string;
  name: string;
  notes: string[]; // stores message IDs
};

