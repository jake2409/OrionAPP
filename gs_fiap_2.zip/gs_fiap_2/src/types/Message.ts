export type Message = {
  id: string;
  text: string;
  createdAt: string; // ISO string for consistency
};

